use std::{error::Error, future::Future, ops::Range, sync::Arc, task::{Context, Poll, Wake, Waker}};
use ext4plus::Ext4Read;
fn run<F: Future>(f: F) -> F::Output {
    struct Noop;
    impl Wake for Noop { fn wake(self: Arc<Self>) {} }
    let waker = Waker::from(Arc::new(Noop));
    let mut f = std::pin::pin!(f);
    match f.as_mut().poll(&mut Context::from_waker(&waker)) {
        Poll::Ready(value) => value,
        Poll::Pending => panic!("synchronous fixture unexpectedly suspended"),
    }
}
struct Reader;
#[async_trait::async_trait]
impl Ext4Read for Reader {
    async fn read(&self, _: u64, dst: &mut [u8]) -> Result<(), Box<dyn Error + Send + Sync>> {
        dst.fill(73); Ok(())
    }
    async fn read_with_io(&self, start: u64, dst: &mut [u8], observed: Range<usize>) -> Result<Option<bool>, Box<dyn Error + Send + Sync>> {
        self.read(start, dst).await?;
        assert_eq!(observed, 4096..8192);
        Ok(Some(true))
    }
}
#[test]
fn default_unknown_retains_data() {
    let bytes = vec![1,2,3];
    let mut dst = [0;2];
    assert_eq!(run(bytes.read_with_io(1, &mut dst, 0..2)).unwrap(), None);
    assert_eq!(dst,[2,3]);
}
#[test]
fn arc_forwards_window_and_provenance() {
    let reader = Arc::new(Reader);
    let mut bytes = [0;8192];
    assert_eq!(run(reader.read_with_io(8192, &mut bytes, 4096..8192)).unwrap(), Some(true));
    assert!(bytes.iter().all(|byte| *byte == 73));
}
