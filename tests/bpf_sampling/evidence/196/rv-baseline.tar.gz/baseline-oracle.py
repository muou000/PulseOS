"""Compare target fault records with QEMU's independent VirtIO read trace.

No timing threshold or kernel-provided classification is used as the I/O
oracle. The guest blocks on stdin at each boundary; the host records the trace
byte cursor before acknowledging it. debugfs bmap binds file pages to sectors.
Trace format: QEMU hw/block/trace-events, virtio_blk_handle_read/rw_complete.
https://github.com/qemu/qemu/blob/v9.2.0/hw/block/trace-events
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import struct
from verify_observation_evidence import check, compare_records, decode_capture, decode_raw

CASES=('anonymous','cold','hot','cow','cached_target_cold_neighbor')
MARKER=re.compile(r'^FAULT_CLASS kind=(\w+) point=(begin|end) address=(\d+) pid=(\d+) tid=(\d+) time_ns=(\d+)\s*$',re.M)
READ=re.compile(r'virtio_blk_handle_read vdev (0x[0-9a-f]+) req (0x[0-9a-f]+) sector (\d+) nsectors (\d+)$')
COMPLETE=re.compile(r'virtio_blk_rw_complete vdev (0x[0-9a-f]+) req (0x[0-9a-f]+) ret (-?\d+)$')


class Boundaries:
    def __init__(self, run: Path):
        self.run=run
        self.rows=[]

    def __call__(self, text, stdin):
        matches=list(MARKER.finditer(text))
        for match in matches[len(self.rows):]:
            kind,point,address,pid,tid,time=match.groups()
            index=len(self.rows)
            check(index < 2*len(CASES) and kind==CASES[index//2]
                  and point==('begin' if index%2==0 else 'end'), 'fault boundary order changed')
            self.rows.append(dict(kind=kind,point=point,address=int(address),pid=int(pid),tid=int(tid),
                                  time_ns=int(time),trace_offset=(self.run/'device-reads.log').stat().st_size))
            (self.run/'fault-boundaries.json').write_text(json.dumps(self.rows,indent=2)+'\n')
            stdin.write(b'g\n');stdin.flush()


def prepare(image, guest_dir, run, helpers):
    data=bytes([0x41])*4096+bytes([0x42])*4096
    source=run/'fault-data'
    source.write_bytes(data)
    check(not any(c in str(source) for c in '\\"\n\r'),'unsupported fixture path')
    target=guest_dir+'/fault-data'
    helpers.debugfs(image,f'write "{source}" {target}',write=True)
    dumped=run/'fault-data-injected'
    helpers.debugfs(image,f'dump {target} "{dumped}"')
    check(dumped.read_bytes()==data,'injected fault data differs')
    dumped.unlink()
    with image.open('rb') as stream:
        stream.seek(1024+24)
        block_size=1024 << struct.unpack('<I',stream.read(4))[0]
    check(block_size in (1024,2048,4096),'unsupported ext4 block geometry')
    pages=[]
    bmap=[]
    for page in range(2):
        extents=[]
        for index in range(page*4096//block_size,(page+1)*4096//block_size):
            output=helpers.debugfs(image,f'bmap {target} {index}')
            bmap.append(output)
            values=re.findall(r'^([0-9]+)\s*$',output,re.M)
            check(len(values)==1 and int(values[0])>0,'fault fixture must not contain sparse blocks')
            extents.append([int(values[0])*block_size//512,block_size//512])
        pages.append(extents)
    layout=dict(path=target,page_bytes=4096,sector_bytes=512,block_bytes=block_size,
                pages=pages,sha256=hashlib.sha256(data).hexdigest())
    (run/'fault-file-layout.json').write_text(json.dumps(layout,indent=2)+'\n')
    (run/'fault-file-bmap.txt').write_text('\n'.join(bmap))
    return layout


def reads(data):
    pending={}; result=[]
    for line in data.decode().splitlines():
        read=READ.search(line)
        completed=COMPLETE.search(line)
        if read:
            dev,req,sector,count=read.groups()
            check((dev,req) not in pending,'device request reused before completion')
            pending[dev,req]=dict(sector=int(sector),sectors=int(count),completed=False)
            check(int(count)>0,'empty device read')
        elif completed:
            dev,req,ret=completed.groups()
            value=pending.pop((dev,req),None)
            if value is not None:
                value.update(completed=True,result=int(ret));result.append(value)
        else:
            check('virtio_blk_' not in line,'malformed device trace')
    return result+list(pending.values())


def overlap(request, extents):
    return sum(max(0,min(request['sector']+request['sectors'],first+count)
                   -max(request['sector'],first)) for first,count in extents)


def verify_cases(records, boundaries, trace, layout):
    check(len(boundaries)==2*len(CASES),'missing/duplicate fault boundaries')
    report={}
    last_time=last_offset=0
    for index,kind in enumerate(CASES):
        begin,end=boundaries[2*index:2*index+2]
        check(begin['kind']==end['kind']==kind and begin['point']=='begin' and end['point']=='end',
              'fault boundary order mismatch')
        check(0<begin['address']==end['address'] and begin['pid']==end['pid']>0
              and begin['tid']==end['tid']>0,'fault boundary identity mismatch')
        check(last_time<=begin['time_ns']<end['time_ns']
              and last_offset<=begin['trace_offset']<=end['trace_offset']<=len(trace),
              'fault boundary time/trace cursor invalid')
        last_time,last_offset=end['time_ns'],end['trace_offset']
        target=[]
        for record in records:
            if record.event!=8:continue
            address,start,elapsed,access,origin,outcome,classification=struct.unpack('<QQQIIII',record.payload)
            if address==begin['address'] and (record.pid,record.tid)==(begin['pid'],begin['tid']) \
                    and begin['time_ns']<=start<=record.time<=end['time_ns']:
                check(origin==2 and outcome==1 and elapsed==record.time-start,'target resolver not successfully completed')
                check(access & (2 if kind=='cow' else 1),'target access direction missing')
                check(classification==(2 if kind=='cold' else 1),'target classification differs from device oracle')
                target.append(record)
        check(len(target)==1,'expected exactly one completed target fault per case')
        device=reads(trace[begin['trace_offset']:end['trace_offset']])
        target_sectors=neighbor_sectors=0
        for request in device:
            target_part=overlap(request,layout['pages'][0])
            neighbor_part=overlap(request,layout['pages'][1])
            if target_part or neighbor_part:
                check(request['completed'] and request['result']==0,'fixture device read did not complete successfully')
            target_sectors+=target_part;neighbor_sectors+=neighbor_part
        check((target_sectors>=8 if kind=='cold' else target_sectors==0),
              'target device-read evidence differs from workload expectation')
        check((neighbor_sectors>=8 if kind=='cached_target_cold_neighbor' else neighbor_sectors==0),
              'neighbor device-read evidence differs from workload expectation')
        report[kind]=dict(classification='major' if kind=='cold' else 'minor',address=begin['address'],
                          pid=begin['pid'],tid=begin['tid'],target_faults=1,target_read_sectors=target_sectors,
                          neighbor_read_sectors=neighbor_sectors,device_requests=device)
    # A supposedly cold page must not have already been read during boot/setup.
    before_cold=reads(trace[:boundaries[2]['trace_offset']])
    check(not any(overlap(request,layout['pages'][0]) or overlap(request,layout['pages'][1])
                  for request in before_cold),'cold fixture was read before the cold phase')
    return dict(kind='fault_classification_evidence',oracle='qemu_virtio_completed_reads',cases=report)


def verify(run):
    run=Path(run)
    inputs=json.loads((run/'inputs.json').read_text())
    records,_=decode_raw((run/'records.pbraw').read_bytes(),'fault')
    normalized,_=decode_capture((run/'capture.pbcapture').read_bytes(),inputs['arch'])
    compare_records(records,normalized)
    text=(run/'guest.log').read_text().replace('\r','')
    check(text.splitlines().count('FAULT_CLASS COMPLETE cases=5')==1,'workload did not complete all classification cases')
    boundaries=json.loads((run/'fault-boundaries.json').read_text())
    markers=list(MARKER.finditer(text))
    check(len(markers)==len(boundaries),'host boundaries differ from actual guest markers')
    for marker,row in zip(markers,boundaries):
        kind,point,address,pid,tid,time=marker.groups()
        check((kind,point,int(address),int(pid),int(tid),int(time)) ==
              tuple(row[key] for key in ('kind','point','address','pid','tid','time_ns')),
              'host boundary metadata differs from guest output')
    report=verify_cases(records,boundaries,(run/'device-reads.log').read_bytes(),
                        json.loads((run/'fault-file-layout.json').read_text()))
    report['arch']=inputs['arch']
    (run/'fault-classification-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    import sys
    print(json.dumps(verify(sys.argv[1]),indent=2))
