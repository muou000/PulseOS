import json,re,subprocess,sys,zlib
from pathlib import Path
repo=Path('/home/muou/PulseOS'); logs=Path('/tmp/pulse213-validation')
sys.path.insert(0,str(repo/'tests/bpf_sampling'))
from archive import chunks,fields,parse_stats
result=json.loads((logs/'regressions.json').read_text())
for fault in ('zero-producer','zero-consumer'):
 for arch in ('riscv64','loongarch64'):
  label=arch+'-'+fault; log=logs/(label+'.log')
  command=[sys.executable,'tests/bpf_sampling/run.py','guest','--arch',arch,'--mode','task','--archive','--fault',fault,'--timeout','240']
  if label!='riscv64-zero-producer':
   with log.open('x') as stream:code=subprocess.run(command,cwd=repo,stdout=stream,stderr=subprocess.STDOUT).returncode
   if code!=1:raise RuntimeError(label+': expected rejected zero-record runtime')
  text=log.read_text()
  if re.search(r'permission denied|read-only file system|operation not permitted',text,re.I):raise PermissionError(text[-3000:])
  run=Path(re.search(r'^Logs: (.+)$',text,re.M)[1]); original=json.loads((run/'result.json').read_text())
  if original['passed'] or not any('empty capture' in error or 'no real samples' in error for error in original['errors']):raise RuntimeError(label+': wrong rejection '+str(original['errors']))
  lines=[re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',line).strip() for line in (run/'guest.log').read_text().splitlines()]
  begin=fields(next(line for line in lines if line.startswith('ARCHIVE BEGIN ')))
  if int(begin['frames']) or int(begin['bytes']):raise RuntimeError(label+': nonempty consumed frames')
  snapshots={}
  for point in ('before','after'):
   raw=chunks(lines,'ARCHIVE STATS_DATA ',point)
   header=fields(next(line for line in lines if line.startswith('ARCHIVE STATS_BEGIN ') and f'point={point} ' in line))
   if len(raw)!=int(header['bytes']) or zlib.crc32(raw)!=int(header['crc']):raise RuntimeError('snapshot CRC')
   snapshots[point]=parse_stats(raw)
  source=[event for event in snapshots['after']['events'].values() if event['scope']=='task']
  if len(source)!=1:raise RuntimeError('source counter identity')
  source=source[0]; before=snapshots['before']['events'][source['fd']]
  deltas={name:source[name]-before[name] for name in ('observed','delivered')}
  if fault=='zero-producer' and any(deltas.values()):raise RuntimeError('producer was not zero')
  if fault=='zero-consumer' and not all(value>0 for value in deltas.values()):raise RuntimeError('producer did not actually deliver')
  proof={'consumed_frames':0,'source_counter_deltas':deltas,'original_capture_export_rejected':True,'original_result':original,'archive_header':begin}
  (run/'zero-evidence.json').write_text(json.dumps(proof,indent=2)+'\n')
  result['runs'].append({'label':label,'path':str(run),'command':command,'returncode':1,'expected_rejection':True,'original_result':original,'zero_evidence':proof,'passed':True})
  (logs/'regressions.json').write_text(json.dumps(result,indent=2)+'\n')
  print('PASS expected rejection',label,deltas,flush=True)
