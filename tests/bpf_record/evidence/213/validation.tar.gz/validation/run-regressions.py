import json, re, subprocess, sys
from pathlib import Path
repo=Path('/home/muou/PulseOS')
logs=Path('/tmp/pulse213-validation')
result={'scope':'fresh specialized scheduler/fault and zero-counter regressions; not production-recorder substitutes','runs':[]}
for mode,extra,expected in [('sched',[],0),('fault',['--fault-classes'],0),('task',['--fault','zero-producer'],1),('task',['--fault','zero-consumer'],1)]:
 for arch in ('riscv64','loongarch64'):
  label=arch+'-'+(extra[-1] if extra else mode)
  command=[sys.executable,'tests/bpf_sampling/run.py','guest','--arch',arch,'--mode',mode,'--archive','--timeout','240',*extra]
  with (logs/(label+'.log')).open('w') as stream:
   code=subprocess.run(command,cwd=repo,stdout=stream,stderr=subprocess.STDOUT).returncode
  text=(logs/(label+'.log')).read_text()
  if re.search(r'permission denied|read-only file system|operation not permitted',text,re.I):
   raise PermissionError(text[-3000:])
  match=re.search(r'^Logs: (.+)$',text,re.M)
  if not match: raise RuntimeError(label+': no preserved run; '+text[-2000:])
  run=Path(match[1]); original=json.loads((run/'result.json').read_text())
  if code!=expected or original['passed']!=(expected==0): raise RuntimeError(label+': unexpected result '+text[-2000:])
  if expected and not any('no real samples' in error for error in original['errors']): raise RuntimeError(label+': negative lacks zero-record rejection '+str(original['errors']))
  row={'label':label,'path':str(run),'command':command,'returncode':code,'expected_rejection':bool(expected),'original_result':original,'passed':True}
  if expected==0:
   verifier='tests/bpf_sampling/fault_class_evidence.py' if mode=='fault' else 'tests/bpf_sampling/verify_observation_evidence.py'
   replay=subprocess.run([sys.executable,verifier,str(run)],cwd=repo,capture_output=True,text=True)
   (logs/(label+'-replay.log')).write_text(replay.stdout+replay.stderr)
   if replay.returncode:raise RuntimeError(label+': independent replay failed '+replay.stderr)
   row['independent_replay']=json.loads(replay.stdout)
  result['runs'].append(row)
  (logs/'regressions.json').write_text(json.dumps(result,indent=2)+'\n')
  print('PASS',label,run,flush=True)
