#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-sigterm || exit 1
/bpf-record-sigterm/record-fixture cpu 2500 sigterm-cpu &
target=$!
/bpf-record-sigterm/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigterm-cpu
/bpf-record-sigterm/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 4000 --buffer-pages 16 --output sigterm-cpu.pbcapture --cpus all --period-ns 10000000 --callchain fp >sigterm-cpu.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigterm-cpu.log; do
  /bpf-record-sigterm/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigterm-cpu.log; exit 1; fi
done
/bpf-record-sigterm/record-fixture sleep 500
kill -15 "$record_pid"
wait "$record_pid"
rc=$?
cat sigterm-cpu.log
echo RECORD_CASE END name=sigterm-cpu rc="$rc"
/bpf-record-sigterm/record-fixture dump sigterm-cpu.pbcapture sigterm-cpu || exit 1
wait "$target" || exit 1
exit 0
