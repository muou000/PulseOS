#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-mixed || exit 1
/bpf-record-mixed/record-fixture mixed 2500 mixed &
target=$!
/bpf-record-mixed/record-fixture sleep 100
echo RECORD_CASE BEGIN name=mixed
/bpf-record-mixed/bpf-record --kernel-elf /boot/kernel.elf --events cpu,cpu,task,sched,fault --duration-ms 1000 --buffer-pages 16 --output mixed.pbcapture --tid "$target" --cpus all --period-ns 10000000 --callchain fp
rc=$?
echo RECORD_CASE END name=mixed rc="$rc"
/bpf-record-mixed/record-fixture dump mixed.pbcapture mixed || exit 1
wait "$target" || exit 1
exit 0
