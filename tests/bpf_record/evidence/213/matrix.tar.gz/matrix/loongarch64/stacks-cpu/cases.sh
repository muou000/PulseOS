#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-cpu || exit 1
/bpf-record-cpu/record-fixture cpu 2500 stack-cpu &
target=$!
/bpf-record-cpu/record-fixture sleep 100
echo RECORD_CASE BEGIN name=stack-cpu
/bpf-record-cpu/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --buffer-pages 16 --output stack-cpu.pbcapture --cpus all --period-ns 10000000 --callchain fp --stack-depth 32
rc=$?
echo RECORD_CASE END name=stack-cpu rc="$rc"
/bpf-record-cpu/record-fixture dump stack-cpu.pbcapture stack-cpu || exit 1
wait "$target" || exit 1
exit 0
