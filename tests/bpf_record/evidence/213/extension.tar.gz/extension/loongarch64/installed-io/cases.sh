#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-io || exit 1
command -v dd >/dev/null || exit 1
dd if=/dev/zero of=/dev/null bs=65536 >installed-io-target.log 2>&1 &
target=$!
/bpf-record-io/record-fixture sleep 100
kill -0 "$target" || { cat installed-io-target.log; exit 1; }
echo INSTALLED_IO READY pid="$target" command=dd if=/dev/zero of=/dev/null bs=65536
echo RECORD_CASE BEGIN name=installed-io
/bpf-record-io/bpf-record --kernel-elf /boot/kernel.elf --events task --tid "$target" --period-ns 1000000 --duration-ms 1000 --buffer-pages 16 --callchain fp --stack-depth 32 --output installed-io.pbcapture
rc=$?
echo RECORD_CASE END name=installed-io rc="$rc"
kill -0 "$target" || { cat installed-io-target.log; exit 1; }
echo INSTALLED_IO ALIVE_AFTER_RECORD pid="$target"
kill "$target" || exit 1
wait "$target"
target_rc=$?
echo INSTALLED_IO STOPPED pid="$target" wait_rc="$target_rc"
cat installed-io-target.log
/bpf-record-io/record-fixture dump installed-io.pbcapture installed-io || exit 1
exit 0
