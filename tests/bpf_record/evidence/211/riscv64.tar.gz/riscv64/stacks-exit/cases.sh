#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-v6ltnun2 || exit 1
/bpf-record-v6ltnun2/record-fixture cpu 2500 target-exit &
target=$!
/bpf-record-v6ltnun2/record-fixture sleep 100
echo RECORD_CASE BEGIN name=target-exit
/bpf-record-v6ltnun2/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 5500 --buffer-pages 16 --output target-exit.pbcapture --tid "$target" --period-ns 10000000 --callchain fp
rc=$?
echo RECORD_CASE END name=target-exit rc="$rc"
/bpf-record-v6ltnun2/record-fixture dump target-exit.pbcapture target-exit || exit 1
wait "$target" || exit 1
exit 0
