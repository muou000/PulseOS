#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-604tbbcc || exit 1
echo RECORD_CASE BEGIN name=snapshot-failure
/bpf-record-604tbbcc/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --output rejected.pbcapture --test-fail-snapshot
rc=$?
echo RECORD_CASE END name=snapshot-failure rc="$rc"
/bpf-record-604tbbcc/record-fixture cpu 2500 journal-failure &
target=$!
/bpf-record-604tbbcc/record-fixture sleep 100
echo RECORD_CASE BEGIN name=journal-failure
/bpf-record-604tbbcc/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --output journal-failure.pbcapture --test-fail-journal
rc=$?
echo RECORD_CASE END name=journal-failure rc="$rc"
/bpf-record-604tbbcc/record-fixture dump journal-failure.pbcapture journal-failure || exit 1
wait "$target" || exit 1
exit 0
