#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-5m4panfx || exit 1
/bpf-record-5m4panfx/record-fixture cpu 2500 stack-task &
target=$!
/bpf-record-5m4panfx/record-fixture sleep 100
echo RECORD_CASE BEGIN name=stack-task
/bpf-record-5m4panfx/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 1000 --buffer-pages 16 --output stack-task.pbcapture --tid "$target" --period-ns 10000000 --callchain fp --stack-depth 32
rc=$?
echo RECORD_CASE END name=stack-task rc="$rc"
/bpf-record-5m4panfx/record-fixture dump stack-task.pbcapture stack-task || exit 1
wait "$target" || exit 1
exit 0
