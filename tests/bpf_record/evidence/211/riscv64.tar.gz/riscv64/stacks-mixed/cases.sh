#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-lzv1xph_ || exit 1
/bpf-record-lzv1xph_/record-fixture mixed 2500 mixed &
target=$!
/bpf-record-lzv1xph_/record-fixture sleep 100
echo RECORD_CASE BEGIN name=mixed
/bpf-record-lzv1xph_/bpf-record --kernel-elf /boot/kernel.elf --events cpu,cpu,task,sched,fault --duration-ms 1000 --buffer-pages 16 --output mixed.pbcapture --tid "$target" --cpus all --period-ns 10000000 --callchain fp
rc=$?
echo RECORD_CASE END name=mixed rc="$rc"
/bpf-record-lzv1xph_/record-fixture dump mixed.pbcapture mixed || exit 1
wait "$target" || exit 1
exit 0
