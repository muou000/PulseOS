#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-unvy26ub || exit 1
echo RECORD_CASE BEGIN name=no-args
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf 
rc=$?
echo RECORD_CASE END name=no-args rc="$rc"
echo RECORD_CASE BEGIN name=offline-cpu
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --cpus 4095
rc=$?
echo RECORD_CASE END name=offline-cpu rc="$rc"
echo RECORD_CASE BEGIN name=duplicate-cpu
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --cpus 0,0
rc=$?
echo RECORD_CASE END name=duplicate-cpu rc="$rc"
echo RECORD_CASE BEGIN name=zero-frequency
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --frequency 0
rc=$?
echo RECORD_CASE END name=zero-frequency rc="$rc"
echo RECORD_CASE BEGIN name=conflicting-rate
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --frequency 99 --period-ns 10000000
rc=$?
echo RECORD_CASE END name=conflicting-rate rc="$rc"
echo RECORD_CASE BEGIN name=unsupported-scope
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --children
rc=$?
echo RECORD_CASE END name=unsupported-scope rc="$rc"
echo RECORD_CASE BEGIN name=bad-buffer
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --buffer-pages 3
rc=$?
echo RECORD_CASE END name=bad-buffer rc="$rc"
echo RECORD_CASE BEGIN name=unsupported-callchain
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --callchain dwarf
rc=$?
echo RECORD_CASE END name=unsupported-callchain rc="$rc"
echo RECORD_CASE BEGIN name=unsupported-stack-depth
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --output rejected.pbcapture --callchain fp --stack-depth 31
rc=$?
echo RECORD_CASE END name=unsupported-stack-depth rc="$rc"
echo RECORD_CASE BEGIN name=task-without-tid
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 100 --output rejected.pbcapture
rc=$?
echo RECORD_CASE END name=task-without-tid rc="$rc"
echo RECORD_CASE BEGIN name=load2
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events sched --cpus 0 --duration-ms 100 --output rejected.pbcapture --test-fail-load 2
rc=$?
echo RECORD_CASE END name=load2 rc="$rc"
echo RECORD_CASE BEGIN name=attach2
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events sched --cpus 0 --duration-ms 100 --output rejected.pbcapture --test-fail-attach 2
rc=$?
echo RECORD_CASE END name=attach2 rc="$rc"
/bpf-record-unvy26ub/record-fixture cpu 1600 write-failure &
target=$!
/bpf-record-unvy26ub/record-fixture sleep 100
echo RECORD_CASE BEGIN name=write-failure
/bpf-record-unvy26ub/bpf-record --kernel-elf /boot/kernel.elf --events cpu --cpus all --duration-ms 100 --output write-failure.pbcapture --test-write-fail-after 1024
rc=$?
echo RECORD_CASE END name=write-failure rc="$rc"
/bpf-record-unvy26ub/record-fixture dump write-failure.pbcapture write-failure || exit 1
wait "$target" || exit 1
exit 0
