#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-m10skdnz || exit 1
sh -c 'i=0; while :; do i=$((i+1)); done' &
target=$!
/bpf-record-m10skdnz/record-fixture sleep 100
echo RECORD_CASE BEGIN name=existing-shell
/bpf-record-m10skdnz/bpf-record --kernel-elf /boot/kernel.elf --events task --tid "$target" --duration-ms 1000 --frequency 99 --callchain fp --output existing-shell.pbcapture
rc=$?
echo RECORD_CASE END name=existing-shell rc="$rc"
/bpf-record-m10skdnz/record-fixture dump existing-shell.pbcapture existing-shell || exit 1
kill "$target"
wait "$target" || true
exit 0
