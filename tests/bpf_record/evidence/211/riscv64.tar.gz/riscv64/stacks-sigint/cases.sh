#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-pp4utg2t || exit 1
/bpf-record-pp4utg2t/record-fixture cpu 2500 sigint &
target=$!
/bpf-record-pp4utg2t/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigint
/bpf-record-pp4utg2t/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 4000 --buffer-pages 16 --output sigint.pbcapture --cpus all --period-ns 10000000 --callchain fp >sigint.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigint.log; do
  /bpf-record-pp4utg2t/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigint.log; exit 1; fi
done
/bpf-record-pp4utg2t/record-fixture sleep 500
kill -2 "$record_pid"
wait "$record_pid"
rc=$?
cat sigint.log
echo RECORD_CASE END name=sigint rc="$rc"
/bpf-record-pp4utg2t/record-fixture dump sigint.pbcapture sigint || exit 1
wait "$target" || exit 1
exit 0
