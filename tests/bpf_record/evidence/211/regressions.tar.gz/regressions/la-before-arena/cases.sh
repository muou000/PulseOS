#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-v1pbhr0a || exit 1
/bpf-record-v1pbhr0a/record-fixture cpu 2500 stack-task &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=stack-task
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 1000 --buffer-pages 16 --output stack-task.pbcapture --tid "$target" --period-ns 10000000 --callchain fp --stack-depth 32
rc=$?
echo RECORD_CASE END name=stack-task rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump stack-task.pbcapture stack-task || exit 1
wait "$target" || exit 1
/bpf-record-v1pbhr0a/record-fixture mixed 11000 mixed &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=mixed
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events cpu,cpu,task,sched,fault --duration-ms 1000 --buffer-pages 16 --output mixed.pbcapture --tid "$target" --cpus all --period-ns 10000000 --callchain fp
rc=$?
echo RECORD_CASE END name=mixed rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump mixed.pbcapture mixed || exit 1
wait "$target" || exit 1
sh -c 'i=0; while :; do i=$((i+1)); done' &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=existing-shell
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events task --tid "$target" --duration-ms 1000 --frequency 99 --callchain fp --output existing-shell.pbcapture
rc=$?
echo RECORD_CASE END name=existing-shell rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump existing-shell.pbcapture existing-shell || exit 1
kill "$target"
wait "$target" || true
/bpf-record-v1pbhr0a/record-fixture cpu 2500 sigint &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigint
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 4000 --buffer-pages 16 --output sigint.pbcapture --cpus all --period-ns 10000000 --callchain fp >sigint.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigint.log; do
  /bpf-record-v1pbhr0a/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigint.log; exit 1; fi
done
/bpf-record-v1pbhr0a/record-fixture sleep 500
kill -2 "$record_pid"
wait "$record_pid"
rc=$?
cat sigint.log
echo RECORD_CASE END name=sigint rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump sigint.pbcapture sigint || exit 1
wait "$target" || exit 1
/bpf-record-v1pbhr0a/record-fixture cpu 2500 target-exit &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=target-exit
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 5500 --buffer-pages 16 --output target-exit.pbcapture --tid "$target" --period-ns 10000000 --callchain fp
rc=$?
echo RECORD_CASE END name=target-exit rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump target-exit.pbcapture target-exit || exit 1
wait "$target" || exit 1
/bpf-record-v1pbhr0a/record-fixture cpu 2500 bounded-export &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=bounded-export
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --buffer-pages 1 --output bounded-export.pbcapture --cpus 0,1 --period-ns 1000000 --record-bytes 4096 --callchain fp
rc=$?
echo RECORD_CASE END name=bounded-export rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump bounded-export.pbcapture bounded-export || exit 1
wait "$target" || exit 1
echo RECORD_CASE BEGIN name=snapshot-failure
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --output rejected.pbcapture --test-fail-snapshot
rc=$?
echo RECORD_CASE END name=snapshot-failure rc="$rc"
/bpf-record-v1pbhr0a/record-fixture cpu 2500 journal-failure &
target=$!
/bpf-record-v1pbhr0a/record-fixture sleep 100
echo RECORD_CASE BEGIN name=journal-failure
/bpf-record-v1pbhr0a/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --output journal-failure.pbcapture --test-fail-journal
rc=$?
echo RECORD_CASE END name=journal-failure rc="$rc"
/bpf-record-v1pbhr0a/record-fixture dump journal-failure.pbcapture journal-failure || exit 1
wait "$target" || exit 1
exit 0
