#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-nmyck7kl || exit 1
rm -f mapping.go
./mapping-fixture mapping >mapping-workload.log 2>&1 &
target=$!
echo RECORD_CASE BEGIN name=mapping-lifecycle
/bpf-record-nmyck7kl/bpf-record --kernel-elf /boot/kernel.elf --events cpu,task --tid "$target" --duration-ms 10000 --callchain fp --output mapping-lifecycle.pbcapture >mapping-record.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' mapping-record.log; do
  /bpf-record-nmyck7kl/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat mapping-record.log; exit 1; fi
done
grep -E '^RECORD (CONFIG|OBSERVATION|ENABLE)' mapping-record.log
: > mapping.go
wait "$target"
target_rc=$?
cat mapping-workload.log
grep -E '^RECORD (DISABLE|QUIESCENT|NO_GROWTH|STOP|ERROR)' mapping-record.log || true
if [ "$target_rc" -ne 0 ]; then cat mapping-record.log; exit 1; fi
wait "$record_pid"
rc=$?
cat mapping-record.log
echo RECORD_CASE END name=mapping-lifecycle rc="$rc"
/bpf-record-nmyck7kl/record-fixture dump mapping-lifecycle.pbcapture mapping-lifecycle || exit 1
exit 0
