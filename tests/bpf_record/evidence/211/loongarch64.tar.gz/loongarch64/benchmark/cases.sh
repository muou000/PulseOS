#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-jrjq6_fd || exit 1
echo BENCH_STATS BEGIN phase=baseline point=before
cat /proc/pulse_bpf_stats || exit 1
echo BENCH_STATS END phase=baseline point=before
/bpf-record-jrjq6_fd/record-fixture cpu 2500 baseline || exit 1
echo BENCH_STATS BEGIN phase=baseline point=after
cat /proc/pulse_bpf_stats || exit 1
echo BENCH_STATS END phase=baseline point=after
/bpf-record-jrjq6_fd/record-fixture cpu 2500 loaded_detached &
target=$!
/bpf-record-jrjq6_fd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=loaded-detached
/bpf-record-jrjq6_fd/bpf-record --kernel-elf /boot/kernel.elf --events cpu --cpus all --duration-ms 1000 --test-detached 1000 --output detached.pbcapture
rc=$?
echo RECORD_CASE END name=loaded-detached rc="$rc"
wait "$target" || exit 1
echo BENCH_STATS BEGIN phase=attached point=before
cat /proc/pulse_bpf_stats || exit 1
echo BENCH_STATS END phase=attached point=before
/bpf-record-jrjq6_fd/record-fixture cpu 2500 attached &
target=$!
/bpf-record-jrjq6_fd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=attached
/bpf-record-jrjq6_fd/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --buffer-pages 16 --output attached.pbcapture --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=attached rc="$rc"
/bpf-record-jrjq6_fd/record-fixture dump attached.pbcapture attached || exit 1
wait "$target" || exit 1
echo BENCH_STATS BEGIN phase=attached point=after
cat /proc/pulse_bpf_stats || exit 1
echo BENCH_STATS END phase=attached point=after
exit 0
