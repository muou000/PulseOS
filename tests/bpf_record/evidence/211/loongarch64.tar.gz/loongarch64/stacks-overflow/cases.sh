#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-p1ohlj5s || exit 1
/bpf-record-p1ohlj5s/record-fixture cpu 2500 bounded-export &
target=$!
/bpf-record-p1ohlj5s/record-fixture sleep 100
echo RECORD_CASE BEGIN name=bounded-export
/bpf-record-p1ohlj5s/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --buffer-pages 1 --output bounded-export.pbcapture --cpus 0,1 --period-ns 1000000 --record-bytes 4096 --callchain fp
rc=$?
echo RECORD_CASE END name=bounded-export rc="$rc"
/bpf-record-p1ohlj5s/record-fixture dump bounded-export.pbcapture bounded-export || exit 1
wait "$target" || exit 1
exit 0
