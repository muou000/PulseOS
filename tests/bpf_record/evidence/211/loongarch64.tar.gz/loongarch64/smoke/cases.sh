#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-azhg0shq || exit 1
/bpf-record-azhg0shq/record-fixture cpu 2500 cpu &
target=$!
/bpf-record-azhg0shq/record-fixture sleep 100
echo RECORD_CASE BEGIN name=cpu
/bpf-record-azhg0shq/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --buffer-pages 16 --output cpu.pbcapture --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=cpu rc="$rc"
/bpf-record-azhg0shq/record-fixture dump cpu.pbcapture cpu || exit 1
wait "$target" || exit 1
/bpf-record-azhg0shq/record-fixture sched 2500 sched &
target=$!
/bpf-record-azhg0shq/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sched
/bpf-record-azhg0shq/bpf-record --kernel-elf /boot/kernel.elf --events sched --duration-ms 1000 --buffer-pages 16 --output sched.pbcapture --cpus all
rc=$?
echo RECORD_CASE END name=sched rc="$rc"
/bpf-record-azhg0shq/record-fixture dump sched.pbcapture sched || exit 1
wait "$target" || exit 1
/bpf-record-azhg0shq/record-fixture fault 2500 fault &
target=$!
/bpf-record-azhg0shq/record-fixture sleep 100
echo RECORD_CASE BEGIN name=fault
/bpf-record-azhg0shq/bpf-record --kernel-elf /boot/kernel.elf --events fault --duration-ms 1000 --buffer-pages 16 --output fault.pbcapture --cpus all
rc=$?
echo RECORD_CASE END name=fault rc="$rc"
/bpf-record-azhg0shq/record-fixture dump fault.pbcapture fault || exit 1
wait "$target" || exit 1
exit 0
