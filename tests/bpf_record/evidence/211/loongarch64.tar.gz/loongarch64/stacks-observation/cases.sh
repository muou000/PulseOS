#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-fod0_m4w || exit 1
echo RECORD_CASE BEGIN name=snapshot-failure
/bpf-record-fod0_m4w/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --output rejected.pbcapture --test-fail-snapshot
rc=$?
echo RECORD_CASE END name=snapshot-failure rc="$rc"
/bpf-record-fod0_m4w/record-fixture cpu 2500 journal-failure &
target=$!
/bpf-record-fod0_m4w/record-fixture sleep 100
echo RECORD_CASE BEGIN name=journal-failure
/bpf-record-fod0_m4w/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 1000 --output journal-failure.pbcapture --test-fail-journal
rc=$?
echo RECORD_CASE END name=journal-failure rc="$rc"
/bpf-record-fod0_m4w/record-fixture dump journal-failure.pbcapture journal-failure || exit 1
wait "$target" || exit 1
exit 0
