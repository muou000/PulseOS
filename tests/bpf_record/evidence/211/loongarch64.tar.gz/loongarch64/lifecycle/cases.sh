#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-dvihgrrp || exit 1
/bpf-record-dvihgrrp/record-fixture cpu 1600 task &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=task
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 100 --buffer-pages 16 --output task.pbcapture --tid "$target" --period-ns 10000000
rc=$?
echo RECORD_CASE END name=task rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump task.pbcapture task || exit 1
wait "$target" || exit 1
/bpf-record-dvihgrrp/record-fixture cpu 1600 dup-close &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=dup-close
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 100 --buffer-pages 16 --output dup-close.pbcapture --tid "$target" --period-ns 10000000 --test-dup-close
rc=$?
echo RECORD_CASE END name=dup-close rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump dup-close.pbcapture dup-close || exit 1
wait "$target" || exit 1
/bpf-record-dvihgrrp/record-fixture cpu 1600 bounded-export &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=bounded-export
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 100 --buffer-pages 1 --output bounded-export.pbcapture --cpus 0,1 --period-ns 1000000 --record-bytes 4096
rc=$?
echo RECORD_CASE END name=bounded-export rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump bounded-export.pbcapture bounded-export || exit 1
wait "$target" || exit 1
sh -c 'i=0; while :; do i=$((i+1)); done' &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=existing-shell
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events task --tid "$target" --duration-ms 100 --frequency 99 --output existing-shell.pbcapture
rc=$?
echo RECORD_CASE END name=existing-shell rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump existing-shell.pbcapture existing-shell || exit 1
kill "$target"
wait "$target" || true
/bpf-record-dvihgrrp/record-fixture cpu 1600 sigint &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigint
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events cpu --duration-ms 3000 --buffer-pages 16 --output sigint.pbcapture --cpus all --period-ns 10000000 >sigint.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigint.log; do
  /bpf-record-dvihgrrp/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigint.log; exit 1; fi
done
/bpf-record-dvihgrrp/record-fixture sleep 100
kill -2 "$record_pid"
wait "$record_pid"
rc=$?
cat sigint.log
echo RECORD_CASE END name=sigint rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump sigint.pbcapture sigint || exit 1
wait "$target" || exit 1
/bpf-record-dvihgrrp/record-fixture fault 1600 sigterm &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigterm
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events fault --duration-ms 3000 --buffer-pages 16 --output sigterm.pbcapture --cpus all >sigterm.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigterm.log; do
  /bpf-record-dvihgrrp/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigterm.log; exit 1; fi
done
/bpf-record-dvihgrrp/record-fixture sleep 100
kill -15 "$record_pid"
wait "$record_pid"
rc=$?
cat sigterm.log
echo RECORD_CASE END name=sigterm rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump sigterm.pbcapture sigterm || exit 1
wait "$target" || exit 1
/bpf-record-dvihgrrp/record-fixture cpu 1600 target-exit &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=target-exit
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events task --duration-ms 4600 --buffer-pages 16 --output target-exit.pbcapture --tid "$target" --period-ns 10000000
rc=$?
echo RECORD_CASE END name=target-exit rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump target-exit.pbcapture target-exit || exit 1
wait "$target" || exit 1
/bpf-record-dvihgrrp/record-fixture mixed 1600 mixed &
target=$!
/bpf-record-dvihgrrp/record-fixture sleep 100
echo RECORD_CASE BEGIN name=mixed
/bpf-record-dvihgrrp/bpf-record --kernel-elf /boot/kernel.elf --events cpu,cpu,task,sched,fault --duration-ms 100 --buffer-pages 16 --output mixed.pbcapture --tid "$target" --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=mixed rc="$rc"
/bpf-record-dvihgrrp/record-fixture dump mixed.pbcapture mixed || exit 1
wait "$target" || exit 1
exit 0
