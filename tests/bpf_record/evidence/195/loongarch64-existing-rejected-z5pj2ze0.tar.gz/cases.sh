#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-z5pj2ze0 || exit 1
sh -c 'command -v dd >/dev/null && command -v sleep >/dev/null || exit 1; echo EXISTING_WORKLOAD READY mode=cpu pid=$$; child=; trap '"'"'[ -z "$child" ] || { kill "$child" 2>/dev/null; wait "$child"; }; exit 0'"'"' TERM INT; while :; do dd if=/dev/zero of=/dev/null bs=1M count=2 2>/dev/null & child=$!; wait "$child" || { echo EXISTING_WORKLOAD_FAIL; exit 1; }; child=; sleep 0.01 & child=$!; wait "$child" || exit 1; child=; done' >existing-cpu-workload.log 2>&1 &
target=$!
/bpf-record-z5pj2ze0/record-fixture sleep 100
kill -0 "$target" || exit 1
echo RECORD_CASE BEGIN name=existing-cpu >existing-cpu-record.log
/bpf-record-z5pj2ze0/bpf-record --events cpu --cpus all --duration-ms 1000 --buffer-pages 16 --record-bytes 131072 --output existing-cpu.pbcapture --period-ns 10000000 >>existing-cpu-record.log 2>&1
rc=$?
echo RECORD_CASE END name=existing-cpu rc="$rc" >>existing-cpu-record.log
kill -0 "$target" || exit 1
kill "$target"
wait "$target" || exit 1
cat existing-cpu-record.log
cat existing-cpu-workload.log
if grep -q EXISTING_WORKLOAD_FAIL existing-cpu-workload.log; then exit 1; fi
/bpf-record-z5pj2ze0/record-fixture dump existing-cpu.pbcapture existing-cpu || exit 1
sh -c 'command -v dd >/dev/null && command -v sleep >/dev/null || exit 1; echo EXISTING_WORKLOAD READY mode=sched pid=$$; child=; trap '"'"'[ -z "$child" ] || { kill "$child" 2>/dev/null; wait "$child"; }; exit 0'"'"' TERM INT; while :; do dd if=/dev/zero of=/dev/null bs=1M count=2 2>/dev/null & child=$!; wait "$child" || { echo EXISTING_WORKLOAD_FAIL; exit 1; }; child=; sleep 0.01 & child=$!; wait "$child" || exit 1; child=; done' >existing-sched-workload.log 2>&1 &
target=$!
/bpf-record-z5pj2ze0/record-fixture sleep 100
kill -0 "$target" || exit 1
echo RECORD_CASE BEGIN name=existing-sched >existing-sched-record.log
/bpf-record-z5pj2ze0/bpf-record --events sched --cpus all --duration-ms 1000 --buffer-pages 16 --record-bytes 131072 --output existing-sched.pbcapture >>existing-sched-record.log 2>&1
rc=$?
echo RECORD_CASE END name=existing-sched rc="$rc" >>existing-sched-record.log
kill -0 "$target" || exit 1
kill "$target"
wait "$target" || exit 1
cat existing-sched-record.log
cat existing-sched-workload.log
if grep -q EXISTING_WORKLOAD_FAIL existing-sched-workload.log; then exit 1; fi
/bpf-record-z5pj2ze0/record-fixture dump existing-sched.pbcapture existing-sched || exit 1
sh -c 'command -v dd >/dev/null && command -v sleep >/dev/null || exit 1; echo EXISTING_WORKLOAD READY mode=fault pid=$$; child=; trap '"'"'[ -z "$child" ] || { kill "$child" 2>/dev/null; wait "$child"; }; exit 0'"'"' TERM INT; while :; do dd if=/dev/zero of=/dev/null bs=1M count=2 2>/dev/null & child=$!; wait "$child" || { echo EXISTING_WORKLOAD_FAIL; exit 1; }; child=; sleep 0.01 & child=$!; wait "$child" || exit 1; child=; done' >existing-fault-workload.log 2>&1 &
target=$!
/bpf-record-z5pj2ze0/record-fixture sleep 100
kill -0 "$target" || exit 1
echo RECORD_CASE BEGIN name=existing-fault >existing-fault-record.log
/bpf-record-z5pj2ze0/bpf-record --events fault --cpus all --duration-ms 1000 --buffer-pages 16 --record-bytes 131072 --output existing-fault.pbcapture >>existing-fault-record.log 2>&1
rc=$?
echo RECORD_CASE END name=existing-fault rc="$rc" >>existing-fault-record.log
kill -0 "$target" || exit 1
kill "$target"
wait "$target" || exit 1
cat existing-fault-record.log
cat existing-fault-workload.log
if grep -q EXISTING_WORKLOAD_FAIL existing-fault-workload.log; then exit 1; fi
/bpf-record-z5pj2ze0/record-fixture dump existing-fault.pbcapture existing-fault || exit 1
exit 0
