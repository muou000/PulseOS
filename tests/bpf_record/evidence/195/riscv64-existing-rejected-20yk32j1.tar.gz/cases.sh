#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-20yk32j1 || exit 1
sh -c 'command -v dd >/dev/null && command -v sleep >/dev/null || exit 1; echo EXISTING_WORKLOAD READY mode=cpu pid=$$; while :; do dd if=/dev/zero of=/dev/null bs=1M count=2 2>/dev/null || { echo EXISTING_WORKLOAD_FAIL; exit 1; }; sleep 0.01 || exit 1; done' >existing-cpu-workload.log 2>&1 &
target=$!
/bpf-record-20yk32j1/record-fixture sleep 100
kill -0 "$target" || exit 1
echo RECORD_CASE BEGIN name=existing-cpu
/bpf-record-20yk32j1/bpf-record --events cpu --cpus all --duration-ms 1000 --buffer-pages 16 --record-bytes 131072 --output existing-cpu.pbcapture --period-ns 10000000
rc=$?
echo RECORD_CASE END name=existing-cpu rc="$rc"
/bpf-record-20yk32j1/record-fixture dump existing-cpu.pbcapture existing-cpu || exit 1
kill -0 "$target" || exit 1
kill "$target"
wait "$target" || true
cat existing-cpu-workload.log
if grep -q EXISTING_WORKLOAD_FAIL existing-cpu-workload.log; then exit 1; fi
sh -c 'command -v dd >/dev/null && command -v sleep >/dev/null || exit 1; echo EXISTING_WORKLOAD READY mode=sched pid=$$; while :; do dd if=/dev/zero of=/dev/null bs=1M count=2 2>/dev/null || { echo EXISTING_WORKLOAD_FAIL; exit 1; }; sleep 0.01 || exit 1; done' >existing-sched-workload.log 2>&1 &
target=$!
/bpf-record-20yk32j1/record-fixture sleep 100
kill -0 "$target" || exit 1
echo RECORD_CASE BEGIN name=existing-sched
/bpf-record-20yk32j1/bpf-record --events sched --cpus all --duration-ms 1000 --buffer-pages 16 --record-bytes 131072 --output existing-sched.pbcapture
rc=$?
echo RECORD_CASE END name=existing-sched rc="$rc"
/bpf-record-20yk32j1/record-fixture dump existing-sched.pbcapture existing-sched || exit 1
kill -0 "$target" || exit 1
kill "$target"
wait "$target" || true
cat existing-sched-workload.log
if grep -q EXISTING_WORKLOAD_FAIL existing-sched-workload.log; then exit 1; fi
sh -c 'command -v dd >/dev/null && command -v sleep >/dev/null || exit 1; echo EXISTING_WORKLOAD READY mode=fault pid=$$; while :; do dd if=/dev/zero of=/dev/null bs=1M count=2 2>/dev/null || { echo EXISTING_WORKLOAD_FAIL; exit 1; }; sleep 0.01 || exit 1; done' >existing-fault-workload.log 2>&1 &
target=$!
/bpf-record-20yk32j1/record-fixture sleep 100
kill -0 "$target" || exit 1
echo RECORD_CASE BEGIN name=existing-fault
/bpf-record-20yk32j1/bpf-record --events fault --cpus all --duration-ms 1000 --buffer-pages 16 --record-bytes 131072 --output existing-fault.pbcapture
rc=$?
echo RECORD_CASE END name=existing-fault rc="$rc"
/bpf-record-20yk32j1/record-fixture dump existing-fault.pbcapture existing-fault || exit 1
kill -0 "$target" || exit 1
kill "$target"
wait "$target" || true
cat existing-fault-workload.log
if grep -q EXISTING_WORKLOAD_FAIL existing-fault-workload.log; then exit 1; fi
exit 0
