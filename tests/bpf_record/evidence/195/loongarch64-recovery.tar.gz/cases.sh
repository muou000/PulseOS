#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-gi1o11kg || exit 1
/bpf-record-gi1o11kg/record-fixture cpu 2500 task &
target=$!
/bpf-record-gi1o11kg/record-fixture sleep 100
echo RECORD_CASE BEGIN name=task
/bpf-record-gi1o11kg/bpf-record --events task --duration-ms 1000 --buffer-pages 16 --output task.pbcapture --tid "$target" --period-ns 10000000
rc=$?
echo RECORD_CASE END name=task rc="$rc"
/bpf-record-gi1o11kg/record-fixture dump task.pbcapture task || exit 1
wait "$target" || exit 1
rm -f exec-thread.tid exec-thread.go
/bpf-record-gi1o11kg/record-fixture exec-thread 1000 >exec-thread-workload.log 2>&1 &
target=$!
ready_waits=0
while [ ! -s exec-thread.tid ]; do
  /bpf-record-gi1o11kg/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat exec-thread-workload.log; exit 1; fi
done
initial_tid=$(cat exec-thread.tid)
echo RECORD_CASE BEGIN name=nonleader-exec
/bpf-record-gi1o11kg/bpf-record --events task --tid "$initial_tid" --duration-ms 10000 --output nonleader-exec.pbcapture >nonleader-exec.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' nonleader-exec.log; do
  /bpf-record-gi1o11kg/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat nonleader-exec.log; exit 1; fi
done
/bpf-record-gi1o11kg/record-fixture sleep 300
: > exec-thread.go
wait "$record_pid"
rc=$?
cat nonleader-exec.log
echo RECORD_CASE END name=nonleader-exec rc="$rc"
wait "$target" || exit 1
cat exec-thread-workload.log
/bpf-record-gi1o11kg/record-fixture dump nonleader-exec.pbcapture nonleader-exec || exit 1
/bpf-record-gi1o11kg/record-fixture cpu 2500 stop-failure &
target=$!
/bpf-record-gi1o11kg/record-fixture sleep 100
echo RECORD_CASE BEGIN name=stop-failure
/bpf-record-gi1o11kg/bpf-record --events cpu --cpus all --duration-ms 1000 --output stop-failure.pbcapture --test-stop-failure
rc=$?
echo RECORD_CASE END name=stop-failure rc="$rc"
/bpf-record-gi1o11kg/record-fixture dump stop-failure.pbcapture stop-failure || exit 1
wait "$target" || exit 1
exit 0
