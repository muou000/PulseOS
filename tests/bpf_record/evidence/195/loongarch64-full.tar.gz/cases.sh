#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-_xla4kkd || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 cpu &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=cpu
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --buffer-pages 16 --output cpu.pbcapture --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=cpu rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump cpu.pbcapture cpu || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture sched 2500 sched &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sched
/bpf-record-_xla4kkd/bpf-record --events sched --duration-ms 1000 --buffer-pages 16 --output sched.pbcapture --cpus all
rc=$?
echo RECORD_CASE END name=sched rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump sched.pbcapture sched || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture fault 2500 fault &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=fault
/bpf-record-_xla4kkd/bpf-record --events fault --duration-ms 1000 --buffer-pages 16 --output fault.pbcapture --cpus all
rc=$?
echo RECORD_CASE END name=fault rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump fault.pbcapture fault || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 task &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=task
/bpf-record-_xla4kkd/bpf-record --events task --duration-ms 1000 --buffer-pages 16 --output task.pbcapture --tid "$target" --period-ns 10000000
rc=$?
echo RECORD_CASE END name=task rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump task.pbcapture task || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 dup-close &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=dup-close
/bpf-record-_xla4kkd/bpf-record --events task --duration-ms 1000 --buffer-pages 16 --output dup-close.pbcapture --tid "$target" --period-ns 10000000 --test-dup-close
rc=$?
echo RECORD_CASE END name=dup-close rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump dup-close.pbcapture dup-close || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 bounded-export &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=bounded-export
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --buffer-pages 1 --output bounded-export.pbcapture --cpus 0,1 --period-ns 1000000 --record-bytes 4096
rc=$?
echo RECORD_CASE END name=bounded-export rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump bounded-export.pbcapture bounded-export || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture mixed 11000 mixed &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=mixed
/bpf-record-_xla4kkd/bpf-record --events cpu,cpu,task,sched,fault --duration-ms 1000 --buffer-pages 16 --output mixed.pbcapture --tid "$target" --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=mixed rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump mixed.pbcapture mixed || exit 1
wait "$target" || exit 1
sh -c 'i=0; while :; do i=$((i+1)); done' &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=existing-shell
/bpf-record-_xla4kkd/bpf-record --events task --tid "$target" --duration-ms 1000 --frequency 99 --output existing-shell.pbcapture
rc=$?
echo RECORD_CASE END name=existing-shell rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump existing-shell.pbcapture existing-shell || exit 1
kill "$target"
wait "$target" || true
/bpf-record-_xla4kkd/record-fixture cpu 2500 sigint &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigint
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 4000 --buffer-pages 16 --output sigint.pbcapture --cpus all --period-ns 10000000 >sigint.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigint.log; do
  /bpf-record-_xla4kkd/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigint.log; exit 1; fi
done
/bpf-record-_xla4kkd/record-fixture sleep 500
kill -2 "$record_pid"
wait "$record_pid"
rc=$?
cat sigint.log
echo RECORD_CASE END name=sigint rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump sigint.pbcapture sigint || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture fault 2500 sigterm &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=sigterm
/bpf-record-_xla4kkd/bpf-record --events fault --duration-ms 4000 --buffer-pages 16 --output sigterm.pbcapture --cpus all >sigterm.log 2>&1 &
record_pid=$!
ready_waits=0
while ! grep -q '^RECORD ENABLE ' sigterm.log; do
  /bpf-record-_xla4kkd/record-fixture sleep 10
  ready_waits=$((ready_waits+1))
  if [ "$ready_waits" -ge 500 ]; then cat sigterm.log; exit 1; fi
done
/bpf-record-_xla4kkd/record-fixture sleep 500
kill -15 "$record_pid"
wait "$record_pid"
rc=$?
cat sigterm.log
echo RECORD_CASE END name=sigterm rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump sigterm.pbcapture sigterm || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 500 target-exit &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=target-exit
/bpf-record-_xla4kkd/bpf-record --events task --duration-ms 1000 --buffer-pages 16 --output target-exit.pbcapture --tid "$target" --period-ns 10000000
rc=$?
echo RECORD_CASE END name=target-exit rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump target-exit.pbcapture target-exit || exit 1
wait "$target" || exit 1
echo RECORD_CASE BEGIN name=no-args
/bpf-record-_xla4kkd/bpf-record 
rc=$?
echo RECORD_CASE END name=no-args rc="$rc"
echo RECORD_CASE BEGIN name=offline-cpu
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --output rejected.pbcapture --cpus 4095
rc=$?
echo RECORD_CASE END name=offline-cpu rc="$rc"
echo RECORD_CASE BEGIN name=duplicate-cpu
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --output rejected.pbcapture --cpus 0,0
rc=$?
echo RECORD_CASE END name=duplicate-cpu rc="$rc"
echo RECORD_CASE BEGIN name=zero-frequency
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --output rejected.pbcapture --frequency 0
rc=$?
echo RECORD_CASE END name=zero-frequency rc="$rc"
echo RECORD_CASE BEGIN name=conflicting-rate
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --output rejected.pbcapture --frequency 99 --period-ns 10000000
rc=$?
echo RECORD_CASE END name=conflicting-rate rc="$rc"
echo RECORD_CASE BEGIN name=unsupported-scope
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --output rejected.pbcapture --children
rc=$?
echo RECORD_CASE END name=unsupported-scope rc="$rc"
echo RECORD_CASE BEGIN name=bad-buffer
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --output rejected.pbcapture --buffer-pages 3
rc=$?
echo RECORD_CASE END name=bad-buffer rc="$rc"
echo RECORD_CASE BEGIN name=task-without-tid
/bpf-record-_xla4kkd/bpf-record --events task --duration-ms 1000 --output rejected.pbcapture
rc=$?
echo RECORD_CASE END name=task-without-tid rc="$rc"
echo RECORD_CASE BEGIN name=load2
/bpf-record-_xla4kkd/bpf-record --events sched --cpus 0 --duration-ms 1000 --output rejected.pbcapture --test-fail-load 2
rc=$?
echo RECORD_CASE END name=load2 rc="$rc"
echo RECORD_CASE BEGIN name=attach2
/bpf-record-_xla4kkd/bpf-record --events sched --cpus 0 --duration-ms 1000 --output rejected.pbcapture --test-fail-attach 2
rc=$?
echo RECORD_CASE END name=attach2 rc="$rc"
/bpf-record-_xla4kkd/record-fixture cpu 2500 write-failure &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=write-failure
/bpf-record-_xla4kkd/bpf-record --events cpu --cpus all --duration-ms 1000 --output write-failure.pbcapture --test-write-fail-after 1024
rc=$?
echo RECORD_CASE END name=write-failure rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump write-failure.pbcapture write-failure || exit 1
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 baseline || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 loaded_detached &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=loaded-detached
/bpf-record-_xla4kkd/bpf-record --events cpu --cpus all --duration-ms 1000 --test-detached 1000 --output detached.pbcapture
rc=$?
echo RECORD_CASE END name=loaded-detached rc="$rc"
wait "$target" || exit 1
/bpf-record-_xla4kkd/record-fixture cpu 2500 attached &
target=$!
/bpf-record-_xla4kkd/record-fixture sleep 100
echo RECORD_CASE BEGIN name=attached
/bpf-record-_xla4kkd/bpf-record --events cpu --duration-ms 1000 --buffer-pages 16 --output attached.pbcapture --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=attached rc="$rc"
/bpf-record-_xla4kkd/record-fixture dump attached.pbcapture attached || exit 1
wait "$target" || exit 1
exit 0
