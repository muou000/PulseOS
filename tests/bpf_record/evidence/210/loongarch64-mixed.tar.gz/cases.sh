#!/bin/sh
set -u
ulimit -c 0
cd /bpf-record-ugb7nc65 || exit 1
/bpf-record-ugb7nc65/record-fixture mixed 11000 mixed &
target=$!
/bpf-record-ugb7nc65/record-fixture sleep 100
echo RECORD_CASE BEGIN name=mixed
/bpf-record-ugb7nc65/bpf-record --events cpu,cpu,task,sched,fault --duration-ms 1000 --buffer-pages 16 --output mixed.pbcapture --tid "$target" --cpus all --period-ns 10000000
rc=$?
echo RECORD_CASE END name=mixed rc="$rc"
/bpf-record-ugb7nc65/record-fixture dump mixed.pbcapture mixed || exit 1
wait "$target" || exit 1
exit 0
