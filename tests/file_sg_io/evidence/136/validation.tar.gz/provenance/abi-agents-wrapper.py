import importlib.util, sys
from pathlib import Path
source = Path('tests/user_abi_reads/run.py').resolve()
spec = importlib.util.spec_from_file_location('abi_runner', source)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original = runner.shutdown.qemu_command
def command(arch, kernel, image):
    argv = original(arch, kernel, image)
    if '-monitor' in argv:
        argv = argv[:argv.index('-monitor')]
    if arch == 'riscv64':
        argv += ['-cpu', 'max']
    return argv
runner.shutdown.qemu_command = command
suite, arch, kernel, output = sys.argv[1:]
sys.argv = [str(source), '--suite', suite, '--arch', arch, '--kernel', kernel, '--log-dir', output]
raise SystemExit(runner.main())
